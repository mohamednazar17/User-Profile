import { Component, OnInit } from '@angular/core';
import { ProfileService } from '../profile.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-profilelist',
  templateUrl: './profilelist.component.html',
  styleUrls: ['./profilelist.component.scss']
})
export class ProfilelistComponent implements OnInit {
  profiles: any[] = [];

  constructor(private profileService: ProfileService, private router: Router,private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.profileService.getProfiles().subscribe(data => {
      this.profiles = data;
      console.log(this.profiles);
    });
    this.route.queryParams.subscribe(params => {
      const nextProfileId = params['nextProfileId'];

      // Move the profile with 'nextProfileId' to the first position
      if (nextProfileId) {
        const index = this.profiles.findIndex(profile => profile.id === nextProfileId);
        if (index !== -1) {
          moveItemInArray(this.profiles, index, 0);
        }
      }
    });
  }

  onYesClick(profile: any): void {
    this.profileService.setSelectedProfile(profile);
    this.router.navigate(['/profileview', profile]);
  }

  onNoClick(): void { }

  onDrop(event: CdkDragDrop<any[]>) {
    moveItemInArray(this.profiles, event.previousIndex, event.currentIndex);
    // Get the profile that was moved
    const movedProfile = this.profiles[event.currentIndex];

    // Call onYesClick with the moved profile
    this.onYesClick(movedProfile);
  }

}
