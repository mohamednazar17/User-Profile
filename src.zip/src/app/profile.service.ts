// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
// export class ProfileService {

//   constructor() { }
// }
// profile.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  private apiUrl = '../assets/profiledata.json'; 

  constructor(private http: HttpClient) {}

  private selectedProfileSubject = new BehaviorSubject<any>(null);
  selectedProfile$ = this.selectedProfileSubject.asObservable();

  setSelectedProfile(profile: any): void {
    this.selectedProfileSubject.next(profile);
  }

  getProfiles(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }
}
