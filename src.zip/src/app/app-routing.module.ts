import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProfilelistComponent } from './profilelist/profilelist.component';
import { ProfileviewComponent } from './profileview/profileview.component';
const routes: Routes = [
  { path: 'profiles', component: ProfilelistComponent },
  { path: 'profileview', component: ProfileviewComponent },
  { path: '', redirectTo: '/profiles', pathMatch: 'full' },
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
