import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProfileService } from '../profile.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-profileview',
  templateUrl: './profileview.component.html',
  styleUrls: ['./profileview.component.scss']
})
export class ProfileviewComponent implements OnInit {
  profileId: any;
  selectedProfile: any;

  constructor(private route: ActivatedRoute, private profileService: ProfileService, private router: Router, private snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.profileId = params.get('id')
      this.profileService.selectedProfile$.subscribe(profile => {
        this.selectedProfile = profile;
      });
    });
  }

  shortlistProfile(value: any) {
    this.snackBar.open('Shortlisted', 'Close', {
      duration: 2000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['interested-toast'] 
    });
  }
  goBack() {
    this.router.navigate(['/profiles']);

  }

  interested() {
    this.snackBar.open('Interested', 'Close', {
      duration: 2000, 
      horizontalPosition: 'center',
      verticalPosition: 'top',
      panelClass: ['interested-toast']
    });
    this.router.navigate(['/profiles'], { queryParams: { nextProfileId: this.selectedProfile.id } });
  }
  notinterested() {
    this.snackBar.open('Not Interested', 'Close', {
      duration: 2000, 
      horizontalPosition: 'center', 
      verticalPosition: 'top',
      panelClass: ['interested-toast']
    });
    this.router.navigate(['/profiles']);
  }

}
